<?php
 return array (
  'Order id is required' => 'Order id is required',
  'Created Successfully' => 'Created Successfully',
  'Message Send Successfully' => 'Message Send Successfully',
  'Message is required' => 'Message is required',
  'Ticket is required' => 'Ticket is required',
  'User is required' => 'User is required',
  'Order id is required' => 'Order id is required',
  'Subject is required' => 'Subject is required',
  'Message is required' => 'Message is required',
  'Ticket created successfully' => 'Ticket created successfully',
  'Order Not Found!' => 'Order Not Found!',
);
 ?>
