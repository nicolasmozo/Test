<?php
 return array (
  'Type of is required' => 'Type of is required',
  'File is required' => 'File is required',
  'Information Submited Successfully. Pls Wait for Conformation' => 'Information Submited Successfully. Pls Wait for Conformation',
  'KYC Verifaction' => 'KYC Verifaction',
  'Send KYC Verifaction' => 'Send KYC Verifaction',
  'Create KYC Document Type' =>'Create KYC Document Type',
  'Edit KYC Document Type' => 'Edit KYC Document Type',
  'Multiple KYC Information Submited under it, so you can not delete it' => 'Multiple KYC Information Submited under it, so you can not delete it',
  'Your Account Is Verified By KYC' => 'Your Account Is Verified By KYC',
  'Deleted Successfully' => 'Deleted Successfully',
  'Message Send Successfully' => 'Message Send Successfully',
  'Closed Successfully' => 'Closed Successfully',
  'Delete Successfully' => 'Delete Successfully',
);
 ?>
