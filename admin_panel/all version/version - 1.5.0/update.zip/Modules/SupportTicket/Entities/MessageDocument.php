<?php

namespace Modules\SupportTicket\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MessageDocument extends Model
{
    use HasFactory;
}
